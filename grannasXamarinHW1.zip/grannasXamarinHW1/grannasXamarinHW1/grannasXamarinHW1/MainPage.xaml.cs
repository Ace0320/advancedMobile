﻿// Author: Kenny Grannas
// Last edit: 2/20/2020

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace grannasXamarinHW1
{
    // Learn more about making custom code visible in the Xamarin.Forms previewer
    // by visiting https://aka.ms/xamarinforms-previewer
    [DesignTimeVisible(false)]
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void Button_Clicked(object sender, EventArgs e)
        {
            //declare vars
            var userInput = inputEntry.Text;
            var aScore = 0;
            var bScore = 0;
            //Go through each character in input
            for(int i = 0; i < userInput.Length; i++)
            {
                //If the character currently on is A
                if (userInput[i].Equals('A')) { 
                    //Add next character to score
                    aScore += userInput[i + 1];
                }
                else if(userInput[i].Equals('B'))
                {
                    //Add next character to score
                    bScore += userInput[i + 1]; 
                }
            }

            //Makes sure there is a winner
            if (aScore >= 11 || bScore >= 11)
            {
                //if A has more by 2
                if (aScore > bScore && (aScore - bScore) > 2)
                {
                    winnerLBL.Text = "Winner: Player A";
                }
                //if B has more by 2
                else if(aScore < bScore && (bScore - aScore) > 2)
                {
                    winnerLBL.Text = "Winner: Player B";
                }
            }
        }
    }
}
