import 'package:grannas_exam0_dart/grannas_exam0_dart.dart';
import 'package:test/test.dart';

void main() {
  test('calculate', () {
    expect(calculate(), 42);
  });
}
